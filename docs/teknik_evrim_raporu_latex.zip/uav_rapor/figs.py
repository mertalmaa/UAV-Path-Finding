import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['TeX Gyre Termes','Liberation Serif','DejaVu Serif'],'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.25,'grid.linewidth':.5})
C1,C2,C3,C4='#1f4e79','#b5651d','#2e7d32','#7a7a7a'
R='/home/claude/report/'
d=json.load(open(R+'data/run31.json'))
fig,ax=plt.subplots(figsize=(6.3,2.9))
ax.fill_between(d['s_km'],d['ground'],min(d['ground'])-40,color='#c9b79c',lw=0,label='Tampolu arazi (60 m max-filtre)')
ax.plot(d['s_km'],np.array(d['ground'])+100,color=C4,lw=.7,ls='--',label='Arazi + 100 m (sert alt sınır)')
ax.plot(d['search_s_km'],d['search_z'],color=C2,lw=.9,label='A* arama irtifası')
ax.plot(d['s_km'],d['z'],color=C1,lw=1.1,label='Profil sonrası nihai irtifa')
ax.set_xlabel('Yatay yol uzunluğu (km)'); ax.set_ylabel('İrtifa MSL (m)')
ax.legend(fontsize=7,loc='upper center',bbox_to_anchor=(.5,-.28),frameon=False,ncol=4); ax.set_xlim(0,max(d['s_km'])); ax.set_ylim(min(d['ground'])-40,720)
fig.tight_layout(); fig.savefig(R+'fig/fig_31km_profile.pdf')
fig,axs=plt.subplots(1,2,figsize=(6.3,2.4),gridspec_kw={'width_ratios':[2.2,1]})
axs[0].plot(d['roll_s'],np.abs(d['roll']),color=C1,lw=.5)
axs[0].axhline(15,color=C2,ls='--',lw=1,label='15°/s sınırı')
axs[0].set_xlabel('Yatay yol uzunluğu (km)'); axs[0].set_ylabel('|yatış hızı| (°/s)'); axs[0].legend(frameon=False,fontsize=7)
hw=np.array(d['half_windows']); vals,cnt=np.unique(np.round(hw,1),return_counts=True)
axs[1].bar([str(v) for v in vals],cnt,color=C1)
axs[1].set_xlabel('Pencere yarı-genişliği (m)'); axs[1].set_ylabel('Birleşim sayısı')
fig.tight_layout(); fig.savefig(R+'fig/fig_rollrate.pdf')
T='/mnt/user-data/uploads/uav_pathfinder/results/test_bilecik/'
cfg=[('bilecik_90km_5_missions_benchmark.json','Önceki yapılandırma (plain)',C4),('bilecik_90km_5_missions_lowalt_benchmark.json','AGL maliyeti A* içinde',C2),('bilecik_90km_5_missions_valley_benchmark.json','Vadi-bağıl rehber (güncel)',C1)]
fig,axs=plt.subplots(1,2,figsize=(6.3,2.6)); w=.27; ids=['M90_01','M90_02','M90_03','M90_04','M90_05']; x=np.arange(5)
for i,(f,l,c) in enumerate(cfg):
    ms={m['mission_id']:m for m in json.load(open(T+f))['missions']}
    e=[ms[k]['expanded_nodes'] for k in ids]; t=[ms[k]['search_time_s'] for k in ids]
    b=axs[0].bar(x+(i-1)*w,e,w,color=c,label=l); axs[1].bar(x+(i-1)*w,t,w,color=c)
    for j,k in enumerate(ids):
        if not ms[k]['success']:
            axs[0].text(x[j]+(i-1)*w,e[j]*1.1,'TIMEOUT',rotation=0,fontsize=5.5,ha='center',va='bottom')
axs[0].set_yscale('log'); axs[0].set_ylabel('Genişletilen düğüm (log)'); axs[1].set_ylabel('Arama süresi (s)')
for a in axs: a.set_xticks(x); a.set_xticklabels([k.replace('M90_','') for k in ids]); a.set_xlabel('Görev (M90_xx)')
fig.legend(*axs[0].get_legend_handles_labels(),fontsize=7,frameon=False,loc='upper center',ncol=3); fig.tight_layout(rect=(0,0,1,.9)); fig.savefig(R+'fig/fig_90km.pdf')
z=[5,10,20,50,100]; red=[0,35.93,66.21,84.32,90.58]; cl=[27.04,57.47,81.05,84.84,90.83]; de=[0,35.57,67.42,85.37,92.21]
fig,ax=plt.subplots(figsize=(4.6,2.4))
ax.plot(z,red,'o-',color=C4,label='Anahtar sayısında azalma (%)'); ax.plot(z,cl,'s-',color=C2,label='Tırmanışta Z bileşeni kaybı (%)'); ax.plot(z,de,'^-',color=C1,label='Alçalışta Z bileşeni kaybı (%)')
ax.set_xscale('log'); ax.set_xticks(z); ax.set_xticklabels(z); ax.set_xlabel('Z kova boyu (m)'); ax.set_ylabel('%'); ax.legend(fontsize=7,frameon=False)
fig.tight_layout(); fig.savefig(R+'fig/fig_zbin.pdf')
v=[('Taban',30000,0),('Tie-break h',30000,0),('F-band 50 m',30000,0),('w=1.01',12855,1),('w=1.05',30000,0),('w=1.10',30000,0),('Pareto Z',30000,0),('MaxK Z=1',30000,0),('Koridor ±150 m',30000,0),('w=1.01+Pareto',6049,1)]
fig,ax=plt.subplots(figsize=(6.3,2.3))
ax.bar([a for a,_,_ in v],[b for _,b,_ in v],color=[C1 if s else C4 for *_,s in v])
ax.axhline(30000,color=C2,ls='--',lw=.8); ax.set_ylabel('Genişletme (30 000 sınır)'); plt.setp(ax.get_xticklabels(),rotation=30,ha='right',fontsize=7.5)
fig.tight_layout(); fig.savefig(R+'fig/fig_missionE.pdf')
print('ok', d['smoothed_max_roll'], max(d['analytic_peaks']))
